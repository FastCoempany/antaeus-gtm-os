import { render } from "preact";
import { Briefing } from "./Briefing";
import { BriefingDS } from "./ds/BriefingDS";
import { BriefingV4 } from "./v4/BriefingV4";
import { bootDensity } from "@/lib/density";
import "@/styles/tokens.css";
import "@/components/components.css";
import "./ds/briefing-ds.css";
import {
    bootBriefingLead,
    bootContrarian,
    bootCostSummary,
    bootPatternMarks,
    bootPatterns,
    bootPendingProposals,
    bootPeriphery,
    bootTriggers
} from "./state";
import { initObservability, isFeatureEnabled } from "@/lib/observability";

initObservability();

const root = document.getElementById("app");
if (!root) {
    throw new Error(
        "Briefing could not mount: #app root element missing from index.html"
    );
}

// Posthog flag exists for future targeting (per-user enable / disable,
// rollout staging). B.0b ships the room ungated — no legacy briefing
// room to redirect from. If the flag is off for a user we log it but
// still render; visibility can be tightened later by hiding the
// palette entry behind the same flag.
const flagOn = isFeatureEnabled("room_briefing_v2");
if (!flagOn) {
    console.info(
        "[briefing] Feature flag room_briefing_v2 is OFF for this user. Rendering anyway."
    );
}

// Design-system migration (canon §6, Intelligence Surface). The DS
// surface composes the room shell + chrome on the component library; the
// already-bright, LLM-pipeline-governed stream content is reused
// unchanged. `?ds=1` is a preview escape-hatch.
const dsParam = (() => {
    try {
        return new URLSearchParams(window.location.search).get("ds");
    } catch {
        return null;
    }
})();
let useDsSurface: boolean;
if (dsParam === "1") {
    useDsSurface = true;
} else if (dsParam === "0") {
    useDsSurface = false;
} else {
    // Default to the new design-system surface; the legacy surface is the
    // safety net, reachable by flipping room_briefing_legacy ON in Posthog.
    useDsSurface = !isFeatureEnabled("room_briefing_legacy");
}

// Wire-to-production v4 (canon §4.21) — the shipped structure with the
// vivid ambient layer (greeting + ticker). Default ON;
// room_briefing_v4_off is the kill-switch; ?v4=0/1 hatches.
const v4Param = (() => {
    try {
        return new URLSearchParams(window.location.search).get("v4");
    } catch {
        return null;
    }
})();
const useV4 =
    v4Param === "1" ||
    (v4Param !== "0" && !isFeatureEnabled("room_briefing_v4_off"));

render(useV4 ? <BriefingV4 /> : useDsSurface ? <BriefingDS /> : <Briefing />, root);

// Boot the density gradient so the DS surface's primitives render at
// the workspace's chosen density (defensive — no-ops without a session).
void bootDensity();

// Load the latest run's Patterns after first paint. Defensive inside
// loadStandardPatterns — failures degrade to the empty state.
void bootPatterns();

// Load armed Watch List triggers + the fires they produced this week.
// Defensive inside the client — failures degrade to empty lists, so
// the Patterns still render.
void bootTriggers();

// Load periphery candidates for the latest run. The rail renders
// nothing when there are none, so a failed read is invisible to the
// operator (the Patterns + Watch List still render).
void bootPeriphery();

// Load contrarian Patterns (pattern_type='contrarian'). Most runs
// won't have any — the LLM is instructed to refuse when no evidence-
// backed challenge exists, and the rail renders nothing when the list
// is empty. So a failed read is also invisible to the operator.
void bootContrarian();

// Load the "Read This Week" lead from the latest completed run.
// Renders nothing when the latest run produced no lead (refused, or
// pre-B.9a).
void bootBriefingLead();

// Load the rolling 7-day cost summary for the footer. Always renders
// once loaded — the cost telemetry is the trust signal that lets the
// operator lean on the auto-run.
void bootCostSummary();

// Load the operator's current Used / Met / Noise marks on Patterns.
// Defensive inside the client — failures degrade to "no marks" (the
// MarksBar just shows the unmarked state). The marks loop back to
// the cluster scorer on the next pipeline run.
void bootPatternMarks();

// Phase F (ADR-017): load any pending proposals the heartbeat wrote.
// Defensive — failures degrade to no surface (SuggestionsSection
// returns null when nothing is pending).
void bootPendingProposals();
